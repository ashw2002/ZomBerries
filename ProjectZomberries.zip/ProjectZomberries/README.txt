# ZomBerries
Game for entry into Callum Upton's Game Jam

Made in Unity 2020.3.13f1

Art, Programing and Sound effects By Ashton Westrick

Music By Sensei (Jeff) Wellman

Pixel Art made in Aseprite,
Sound Effects made with BFXR

Contact Info: aawestrick@gmail.com
Make fun of my code here: https://github.com/ashw2002/ZomBerries

Enjoy the game and long live nightmare world!

I didn't have time to implement a Pause menu, so If you want to quit just Alt +F4